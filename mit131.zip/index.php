<!DOCTYPE html>
<html>
<head>
	<title>MIT 131 Activities</title>
</head>
<body>

<h2>Activities</h2>

<ul>
	<li><a href="activity1.php">Activity 1</a></li>
	<li><a href="activity2.php">Activity 2</a></li>
	<li><a href="activity3.php">Activity 3</a></li>
</ul>

</body>
</html>